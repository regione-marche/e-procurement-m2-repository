--------------------------------
-- AGGIORNAMENTO SITAT/VIGILANZA
-- Database: DB2
------------------------------

------------------------------
-- SITATSA 2.7.2.b
------------------------------
UPDATE SITATSA.ELDAVER SET NUMVER='2.7.2.b', DATVET=CURRENT TIMESTAMP WHERE CODAPP='W9';
