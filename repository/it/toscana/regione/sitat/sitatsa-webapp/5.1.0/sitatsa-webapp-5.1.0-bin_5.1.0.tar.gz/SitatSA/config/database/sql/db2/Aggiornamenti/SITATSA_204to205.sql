------------------------------
-- AGGIORNAMENTO TABELLE SITAT	
------------------------------
-- GENE 1.4.39
-- GENEWEB 1.5.5
-- SITATSA 2.0.5
--------------------------

-- SITAT



UPDATE SITATSA.ELDAVER Set numver='2.0.5' where codapp='W9';