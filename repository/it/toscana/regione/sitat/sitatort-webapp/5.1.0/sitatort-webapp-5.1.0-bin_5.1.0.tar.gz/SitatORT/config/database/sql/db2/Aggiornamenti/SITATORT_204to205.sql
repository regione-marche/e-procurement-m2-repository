------------------------------
-- AGGIORNAMENTO TABELLE SITAT	
------------------------------
-- GENE 1.4.39
-- GENEWEB 1.5.5
-- SITATORT 2.0.5
--------------------------

-- SITAT



UPDATE SITATORT.ELDAVER Set numver='2.0.5' where codapp='W9';