--------------------------------
-- AGGIORNAMENTO SITAT/VIGILANZA
-- Database: DB2
------------------------------

------------------------------
-- SITATORT 2.7.2.b
------------------------------
UPDATE SITATORT.ELDAVER SET NUMVER='2.7.2.b', DATVET=CURRENT TIMESTAMP WHERE CODAPP='W9';
