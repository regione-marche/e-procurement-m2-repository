------------------------------
-- AGGIORNAMENTO SITAT 	
------------------------------
-- GENE 1.4.39
-- GENEWEB 1.5.5
-- SITAT 2.0.1
--------------------------



UPDATE SITATORT.ELDAVER Set numver='2.0.1' where codapp='W9';